//
//  SwiftClass.swift
//  SwiftTestOne
//
//  Created by Bob Pascazio on 2/4/15.
//  Copyright (c) 2015 Pace. All rights reserved.
//

import Foundation

@objc public class MySwiftClass : NSObject {
    
    @objc func printSomething() {
        println("this is swift code running from obj-c");
    }
}