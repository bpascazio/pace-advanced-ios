//
//  MyClass.m
//  SwiftTestOne
//
//  Created by Bob Pascazio on 2/4/15.
//  Copyright (c) 2015 Pace. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SwiftTestOne-Swift.h"
#import "MyClass.h"

@implementation CustomObject

- (void) someMethod {
    NSLog(@"SomeMethod Ran");
    
    MySwiftClass* sclass = [[MySwiftClass alloc] init];
    [sclass printSomething];
    
}

@end