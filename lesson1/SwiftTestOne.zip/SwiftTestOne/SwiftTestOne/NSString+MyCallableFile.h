//
//  NSString+MyCallableFile.h
//  SwiftTestOne
//
//  Created by Bob Pascazio on 2/4/15.
//  Copyright (c) 2015 Pace. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MyCallableFile)

@end
