//
//  MyClass.h
//  SwiftTestOne
//
//  Created by Bob Pascazio on 2/4/15.
//  Copyright (c) 2015 Pace. All rights reserved.
//

#ifndef SwiftTestOne_MyClass_h
#define SwiftTestOne_MyClass_h

#import <Foundation/Foundation.h>

@interface CustomObject : NSObject

@property (strong, nonatomic) id someProperty;

- (void) someMethod;

@end

#endif
