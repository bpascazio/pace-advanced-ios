//
//  ViewController.swift
//  SwiftTestOne
//
//  Created by Bob Pascazio on 2/4/15.
//  Copyright (c) 2015 Pace. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    @IBOutlet var textField: UILabel!

    @IBOutlet weak var hii: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func fun(sender: AnyObject) {
        var instanceOfCustomObject: CustomObject = CustomObject()
        instanceOfCustomObject.someProperty = "Hello World"
        println(instanceOfCustomObject.someProperty)
        instanceOfCustomObject.someMethod()
    }
    
    @IBAction func buttonTapped(AnyObject) {
        println("button tapped!")
        textField.text = "tap"
    }

}

